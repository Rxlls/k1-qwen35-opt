#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "spine-runtime::spert" for configuration "Release"
set_property(TARGET spine-runtime::spert APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(spine-runtime::spert PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libspert.so.0.6.3"
  IMPORTED_SONAME_RELEASE "libspert.so.1"
  )

list(APPEND _cmake_import_check_targets spine-runtime::spert )
list(APPEND _cmake_import_check_files_for_spine-runtime::spert "${_IMPORT_PREFIX}/lib/libspert.so.0.6.3" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
